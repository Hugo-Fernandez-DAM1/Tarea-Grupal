package logica;

import modelo.Voto;
import persistencia.ConexionMYSQL;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Operaciones {
    public static Connection getConnection(){
        return ConexionMYSQL.getInstance().getConn();
    }
    public static List<Voto> ultimosVotos(){
        List<Voto> votos=new ArrayList<>();
        String sql="SELECT usuario,fecha,cancion FROM votos ORDER BY fecha DESC LIMIT 10";
        try(Statement stmt=getConnection().createStatement();
        ResultSet rs=stmt.executeQuery(sql)){
            while(rs.next()){
                Voto V1=new Voto();
                votos.add(V1);
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }
        return votos;
    }
    public static void modificarUsuario(){
   }
    public void eliminarVoto(){

    }
    public static Voto crearVoto(final ResultSet rs)throws SQLException{
        return new Voto(rs.getString(1),rs.getDate(2).toLocalDate(),rs.getInt(3));
    }
}
