package modelo;

import java.time.LocalDate;

public class Voto {
    private String usuario;
    private LocalDate fecha;
    private int nCancion;

    public Voto(String) {
    }
}
